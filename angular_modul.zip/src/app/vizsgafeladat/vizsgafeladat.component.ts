import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {
  suly!: number;
  magassag!: number;

  TestTomegIndex(): number {
    const index: number = this.suly / (this.magassag ** 2);
    return index;
  }

  eredmenyek: string[] = [];

  eredmenyMentes(): void {
    this.eredmenyek.push(
      "Az " +
        this.suly +
        " kg testsúlyú és " +
        this.magassag +
        " m magasságú ember testtömeg indexe: " +
        this.TestTomegIndex()
    );
  }
}
